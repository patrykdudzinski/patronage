var kliki = 0;
function onClick() {
    kliki = kliki + 1;
    document.getElementById("clickCount").innerHTML = kliki;
}

