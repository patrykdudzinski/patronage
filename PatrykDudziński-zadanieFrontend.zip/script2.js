 var licznik = setInterval(
      function (){
        document.getElementById("clickCount").innerHTML = 0;
        kliki = 0;
        clearInterval; } ,30000);          